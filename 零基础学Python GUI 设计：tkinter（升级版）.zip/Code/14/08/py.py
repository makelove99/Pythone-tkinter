#  _*_ coding:utf-8 _*_
# 开发团队：明日科技
# 开发人员：Administrator
# 开发时间：2023/11/30  9:09
# 文件名称：py.py
# 开发工具：PyCharm

import pymysql

# 打开数据库连接
db = pymysql.connect(host="localhost",user="root",password="root",database="mrsoft")
# 使用cursor()方法获取操作游标
cursor = db.cursor()
# 数据列表
data = [("零基础学Python（升级版）", 'Python', 99.00, '2024-1-10'),
        ("零基础学C语言（升级版）", 'C语言', 99.00, '2024-1-10'),
        ("零基础学PyQt", 'Python', 99.00, '2024-1-10'),
        ("零基础学Python数据分析", 'Python', 99.00, '2024-1-10'),
        ("零基础学Python网络爬虫", 'Python', 99.00, '2024-1-10'),
        ]
try:
    # 执行sql语句，插入多条数据
    cursor.executemany("insert into books(name, category, price, publish_time) values (%s,%s,%s,%s)", data)
    # 提交数据
    db.commit()
except:
    # 发生错误时回滚
    db.rollback()
# 关闭数据库连接
db.close()
