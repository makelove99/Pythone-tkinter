/*
Navicat MySQL Data Transfer

Source Server         : mr
Source Server Version : 80035
Source Host           : localhost:3306
Source Database       : mrsoft

Target Server Type    : MYSQL
Target Server Version : 80035
File Encoding         : 65001

Date: 2023-12-01 14:02:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `books`
-- ----------------------------
DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `publish_time` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of books
-- ----------------------------
INSERT INTO `books` VALUES ('1', '零基础学Python（升级版）', 'Python', '99.00', '2024-01-10');
INSERT INTO `books` VALUES ('2', '零基础学C语言（升级版）', 'C语言', '89.00', '2024-01-15');
INSERT INTO `books` VALUES ('3', '零基础学PyQt', 'Python', '99.00', '2024-01-10');
INSERT INTO `books` VALUES ('4', '零基础学Python数据分析', 'Python', '99.00', '2024-01-10');
INSERT INTO `books` VALUES ('5', '零基础学Python网络爬虫', 'Python', '99.00', '2024-01-10');
