# _*_coding:UTF-8 _*_
# 开发团队：明日科技
# 开发人员：pc
# 文件名称：py.py
# 开发工具：PyCharm


from tkinter import *

win = Tk()
win.geometry("300x200")
Label(win, text="小扣柴扉久不开", foreground="red", background="#C3DEEF").pack()
# Label(win, text="小扣柴扉久不开", fg="red", bg="#C3DEEF",width=20,height=3).pack()
# Label(win, text="小扣柴扉久不开", fg="red", bg="#C3DEEF",width=20,height=3,anchor="nw").pack()
# Label(win, text="小扣柴扉久不开", fg="red", bg="#C3DEEF",padx=20,pady=10).pack()
# Label(win, text="小扣柴扉久不开", fg="red", bg="#C3DEEF",font="华文新魏 16 bold").pack()
win.mainloop()

